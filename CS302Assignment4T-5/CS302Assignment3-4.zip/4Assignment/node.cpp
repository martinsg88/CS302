class nodetype
{
	friend class stacktype;
	friend class queuetype;
	
	public:
		int i;
		int j;
		nodetype *next;
};
