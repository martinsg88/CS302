#include "RegionType.h"
#include <cstdlib>

//Constructor-------------------------------------------------------------------
RegionType::RegionType()
{
	regionID = 0;
	regionSize = 0;
	Xcentroid = 0;	
	Ycentroid = 0;
	//PixelType = ...;
}
//------------------------------------------------------------------------------
RegionType& RegionType::operator=(RegionType& regionObject)
{
	regionID = regionObject.regionID;
	regionSize = regionObject.regionSize;
	Xcentroid = regionObject.Xcentroid;
	Ycentroid = regionObject.Ycentroid;
	//PixelType = ...
}
//------------------------------------------------------------------------------
RegionType::~RegionType()
{
 	regionID = 0;
	regionSize = 0;
	Xcentroid = 0;
	Ycentroid = 0;
	//PixelType = ...;
}
//------------------------------------------------------------------------------
