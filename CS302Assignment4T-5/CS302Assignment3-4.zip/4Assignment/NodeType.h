#ifndef NODETYPE_H
#define NODETYPE_H

template <class ItemType>
class NodeType
{
	public:
	ItemType info;
	NodeType *next;
};
#endif
