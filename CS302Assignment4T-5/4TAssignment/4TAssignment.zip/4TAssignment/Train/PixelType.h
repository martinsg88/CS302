#ifndef PIXELTYPE_H
#define PIXELTYPE_H

#include <cstdlib>

class PixelType
{
public:
  int i;
  int j;

  PixelType();								//default constructor
  PixelType(PixelType&);				//copy constructor
  void insert(int y, int x);			
  PixelType& operator= (PixelType&);
  ~PixelType();
};
#endif
