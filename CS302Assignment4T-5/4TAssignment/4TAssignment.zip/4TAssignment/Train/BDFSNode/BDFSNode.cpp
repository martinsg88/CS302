class BDFSNodeType
{
	friend class stacktype;
	friend class queuetype;
	
	public:
		int i;
		int j;
		BDFSNodeType *next;
};
