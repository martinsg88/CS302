//train.cpp
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <string>
#include <cmath>

#include "image.h"
#include "DFSstack.h"
#include "BFSqueue.h"
#include "RegionType.h"
#include "RegionList.h"
#include "PixelType.h"
#include "PixelList.h"

using namespace std;


int displayMenu();

//prototype to validate user's response
char validateResponse();

//prototype to execute case statements
void executeCases(int choice, float[][2]);

void trainPennies(ImageType&, float[][2]);

void trainNickels(ImageType&, float[][2]);

void trainDimes(ImageType&, float[][2]);

void trainQuarters(ImageType&, float[][2]);

void trainDollars(ImageType&, float[][2]);

void processImage(ImageType&, RegionList<RegionType>&);

void findComponentBFS(ImageType&, ImageType&, RegionList<RegionType>&);

void deleteSmallHoles(RegionList<RegionType>&, int);

void computeRegionCentroid(RegionList<RegionType>&);

void saveStats(float, float, float[][2], int);

int readImageHeader(char[], int&, int&, int&, bool&);

int readImage(char[], ImageType&);

int writeImage(char[], ImageType&);

void coinStats(RegionList<RegionType>&, float&, float&);
//==============================================================================
int main(int argc, char *argv[])
{
	char response;//variable to hold user's response
	float coinSize[5][2];//array to hold coin mean and standard de
	int choice;

	//initialize CoinSize array
	for (int i = 0; i < 5; i++)
		for(int j = 0; j < 2; j++)
			coinSize[i][j] = 0;

	do
		{
			choice = displayMenu();

			executeCases(choice, coinSize);

			response = validateResponse();
		}
	
	while(response == 'Y' || response == 'y');//repeat do loop if Y/y

	return (1);

}
//==============================================================================
int displayMenu()
{
	int choice;

		cout << "\nPlease choose from the following menu options:\n\n";

		cout << "(1) Train Pennies"	<< endl;
		cout << "(2) Train Nickels"	<< endl;
		cout << "(3) Train Dimes"		<< endl;
		cout << "(4) Train Quarters"	<< endl;
		cout << "(5) Train Dollars"	<< endl;
		cout << "(6) Finish Training"	<< endl;

		cout << "\nSelection: ";
		cin >> choice;

	while(choice < 1 || choice > 6)//check the selection
		{
			cout << "Selection must be between 1 and 6. Enter again.";
			cin >> choice;
		}

	if(choice == 6)
		{
			cout << "\nThanks for using the system." << endl;
		}

	return choice;
}
//------------------------------------------------------------------------------
char validateResponse()
{
	char response;//variable to hold user's response

	cout << "\nMake another selection (Y/y or N/n)? ";
	cin >> response;

	while(response != 'Y' && response != 'y' &&
			response != 'N' && response != 'n')//validate enty
				{
					cout << "\nResponse must be Y/y or N/n. Enter again: ";
					cin >> response;//get input again
				}

	return response;
}
//------------------------------------------------------------------------------
void executeCases(int choice, float coinSize[][2])
{
	ImageType image;
	int size;

	switch (choice)
	{
		case 1:	
				trainPennies(image, coinSize);//process pennies
		break;

		case 2:	
				trainNickels(image, coinSize);//process nickels
		break;

		case 3:	
				trainDimes(image, coinSize);//process dimes
		break;

		case 4:	
				trainQuarters(image, coinSize);//process quarters
		break;

		case 5:	
				trainDollars(image, coinSize);//process dollars
		break;

		case 6: 
				cout << "Training Completed!" << endl;
		break;

		default:

			cout << "Invalid input. Try again!" << endl;

		}
}
//------------------------------------------------------------------------------
void trainPennies(ImageType& image, float coinSize[][2])
{	
	int size = 0;
	float mean = 0;
	float StdDev = 0;

   RegionType regionType;
   RegionList<RegionType> regionList;

	cout << "Getting ready to process image...\n";

	processImage(image, regionList);

	//output Number of Regions to test for avg size
   cout << "\nNumber of Regions: "<< regionList.LengthIs() <<endl;

   coinStats(regionList, mean, StdDev);

	coinSize[size][0] = mean;
	coinSize[size][1] = StdDev;

   saveStats(mean, StdDev, coinSize, size);//save stats to file

   cout << "\nPenny Stats is Located in trainStats.txt.\n";
	cout << "The mean size is " << mean << " and the Standard Deviation is ";
	cout << StdDev << ".\n";
}
//------------------------------------------------------------------------------
void trainNickels(ImageType& image, float coinSize[][2])
{
	int size = 1;
	float mean = 0;
	float StdDev = 0;

   RegionType regionType;
   RegionList<RegionType> regionList;

	processImage(image, regionList);

	//output Number of Regions to test for avg size
   cout<<"Number of Regions: "<< regionList.LengthIs() <<endl;

   coinStats(regionList, mean, StdDev);

	coinSize[size][0] = mean;
	coinSize[size][1] = StdDev;
	
   saveStats(mean, StdDev, coinSize, size);//save stats to file 

   cout << "\nNickel Stats is Located in trainStats.txt.\n";
	cout << "The mean size is " << mean << " and the Standard Deviation is ";
	cout << StdDev << ".\n";
}
//------------------------------------------------------------------------------
void trainDimes(ImageType& image, float coinSize[][2])
{
	int size = 2;
	float mean = 0;
	float StdDev = 0;

   RegionType regionType;
   RegionList<RegionType> regionList;

	processImage(image, regionList);

	//output Number of Regions to test for avg size
   cout<<"Number of Regions: "<< regionList.LengthIs() << endl;

   coinStats(regionList, mean, StdDev);

	coinSize[2][0] = mean;
	coinSize[2][1] = StdDev;

   saveStats(mean, StdDev, coinSize, size);//save stats to file 

   cout << "\nDimes Stats is Located in trainStats.txt.\n";
	cout << "The mean size is " << mean << " and the Standard Deviation is ";
	cout << StdDev << ".\n";
}
//------------------------------------------------------------------------------
void trainQuarters(ImageType& image, float coinSize[][2])
{
	int size = 3;
	float mean = 0;
	float StdDev = 0;

   RegionType regionType;
   RegionList<RegionType> regionList;

	processImage(image, regionList);

	//output Number of Regions to test for avg size
   cout<<"Number of Regions: "<< regionList.LengthIs() << endl;

   coinStats(regionList, mean, StdDev);

	coinSize[3][0] = mean;
	coinSize[3][1] = StdDev;

   saveStats(mean, StdDev, coinSize, size);//save stats to file 

   cout << "\nQuarter Stats is Located in trainStats.txt.\n";
	cout << "The mean size is " << mean << " and the Standard Deviation is ";
	cout << StdDev << ".\n";
}
//------------------------------------------------------------------------------
void trainDollars(ImageType& image, float coinSize[][2])
{
	int size = 4;
	float mean = 0;
	float StdDev = 0;

   RegionType regionType;
   RegionList<RegionType> regionList;

	processImage(image, regionList);

	//output Number of Regions to test for avg size
   cout<<"Number of Regions: "<< regionList.LengthIs() << endl;

   coinStats(regionList, mean, StdDev);

	coinSize[4][0] = mean;
	coinSize[4][1] = StdDev;

   saveStats(mean, StdDev, coinSize, size);//save stats to file 

   cout << "\nDollar Stats is Located in trainStats.txt.\n";
	cout << "The mean size is " << mean << " and the Standard Deviation is ";
	cout << StdDev << ".\n\n";
}
//------------------------------------------------------------------------------
void processImage(ImageType& image, RegionList<RegionType>& regionList)
{
	cout << "\nProcessing image...\n";

	int N, M, Q;
	bool type;
	char inputName[25], outputName[25];
	int threshold;
	ImageType Histogram(256, 256, 255); //declare an object to hold a histogram
	
	cout << "\nEnter the name of the coins file to process:  ";
	cin >> inputName;

	cout << "\nReading image header...";
	readImageHeader(inputName, N, M, Q, type);
	
	cout << "\nSetting image info...";
	ImageType image2(N, M, Q);
	
	cout << "\nReading image...\n";
	readImage(inputName, image2);
	image = image2;	

	ImageType outputImage(N,M,Q);
	
	for(int i = 0; i < N; i++)
	{
		for(int j = 0; j < M; j++)
		{
			outputImage.setPixelVal(i, j, 255);
		}
	}

	// create histogram
	Histogram = image.displayHistogram(image, threshold);
	cout << "\nCoin image has been processed; auto-threshold is " << threshold;
	cout << ".\nHistogram created. Enter the name of your Histogram file: ";
	cin >> outputName;
	writeImage(outputName, Histogram);
	cout << "\nExamine histogram for threshold value...\n";

	// threshhold image
	cout << "\nEnter threshold value: ";
	cin >> threshold;
	image.threshold(threshold, image);

	// dilate image
	image.dilate(image);

	// erode image
	image.erode(image);
	
	//ConnectedComponents
	findComponentBFS(image, outputImage, regionList);
	}
//------------------------------------------------------------------------------
void findComponentBFS(ImageType& image, ImageType& outputImage,
															RegionList<RegionType>& regionList)
{
	int vall, vali, valo, trash = 0, size = 0;//size is pixel counter
	int popi, popj, sumX = 0, sumY = 0, coinID;
	int N,M,Q; //get image info
	int marker = -1, coinComp = 0, label = 200;
	char outputName[25];
	PixelType pixelType;
	PixelType tempPixelType;
	RegionType regionType;
	PixelList<PixelType> pixelList;

	queuetype queue;//declare a queue
	
	queue.makeEmpty();
	
	outputImage.getImageInfo(N, M, Q);
		
		for(int i = 1; i < N-1; i++)//start checking the entire image
		{//first for
			for(int j = 1; j < M-1; j++)
			{//second for
				image.getPixelVal(i,j,vali);
				if(vali == 255)
				{//first if
					pixelList.MakeEmpty();
					image.setPixelVal(i,j,0);
					queue.enqueue(i,j);
					trash = 1;
					while(!queue.isEmpty())
					{//open while
						queue.dequeue(popi, popj);//check nearest neighbors
						pixelType.insert(popi, popj);//insert i & j into a pixType nde
						pixelList.InsertItem(pixelType);//insert pType node into list
						for(int k = popi-1; k < popi+2; k++)
						{//third for
							for(int l = popj-1; l <popj+2; l++)
							{	
								image.getPixelVal(k, l, vali);
								if(vali == 255)
								{
									trash++;
									queue.enqueue(k, l);
									image.setPixelVal(k, l, 0);
								}				
							}
						}//third for
							outputImage.setPixelVal(popi,popj,label);
							regionType.insert(coinID, size, sumX, sumY, pixelList);
					}//close while	

					if(trash > 30 )
					{
						++coinComp;//coin counter
						label = label - 30;
						regionType.regionSize = pixelList.LengthIs();
						regionList.InsertItem(regionType);
					}

					else
					{
						deleteSmallHoles(regionList, 30);
					}
				}//first if
			}//second for
		}//first for

		//set the background to black
		for(int i = 1; i < N-1; i++)
		{
			for(int j = 1; j < M-1; j++)
			{
				outputImage.getPixelVal(i,j,valo);
				if(valo == 255)
				outputImage.setPixelVal(i,j,0);
			}
		}
	computeRegionCentroid(regionList);
}
//------------------------------------------------------------------------------
void deleteSmallHoles(RegionList<RegionType>& regionList, int size)
{
     int testsize = 0;
     bool done = true;	
     RegionType tempregion;
	
     regionList.ResetList();

     while(!done)
     {
 			regionList.GetNextItem(tempregion);
			testsize = tempregion.regionSize;
		if(testsize > size)
	  			done = true;
		else
	   	regionList.ByeTrash(tempregion); 
   }
}
//------------------------------------------------------------------------------
void computeRegionCentroid(RegionList<RegionType>& regionList)
{
	cout << "\nComputing centroids...\n";
	int sumX = 0, sumY = 0, pixelCounter = 0;

	RegionType regionType;
	PixelType pixelType;

	regionList.ResetList();
	
	cout << "\nNumber of Regions is " << regionList.LengthIs() << endl;

	while(!regionList.IsLastItem())
	{
		regionList.GetNextItem(regionType);	//get first/next region
		regionType.pixelList.ResetList();	//set/reset region's pixel list
		sumX = 0;									//set/reset x centroid
		sumY = 0;									//set/reset y centroid
		pixelCounter = 0;							//set/reset pixel counter

		while(!regionType.pixelList.IsLastItem())
		{
			regionType.pixelList.GetNextItem(pixelType);
			sumX += pixelType.i;	//sum the x coordinates
			sumY += pixelType.j;	//sum the y coordinates
			pixelCounter++;		//increment the counter
		}

		regionType.Xcentroid = sumX/pixelCounter;
		regionType.Ycentroid = sumY/pixelCounter;

		cout << "\nCentroid X is " << sumX/pixelCounter;
		cout << " Centroid Y is " << sumY/pixelCounter << endl;

	}	
}
//------------------------------------------------------------------------------
void coinStats(RegionList<RegionType>& regionList, float& mean, float& StdDev)
{
	int arraysize = regionList.LengthIs(); 
	
	int coinSize[arraysize];
	float sum = 0;
	float dev = 0;

	StdDev = 0;
	mean = 0;

	RegionType tempregion;

 	regionList.ResetList();
  
	for(int i= 0; i < arraysize; i++)
	{
      regionList.GetNextItem(tempregion);
		//store the size into the counter of one coin
      coinSize[i]= tempregion.regionSize;
	}

	for(int i = 0; i< arraysize; i++)
	{
		sum += coinSize[i];
	}

		mean = (sum/arraysize);//compute mean

	for(int j = 0; j< arraysize; j++)
	{
		dev += pow((coinSize[j] - mean),2);//compute deviation
	}
	if(arraysize > 1 )
	{
		StdDev = sqrt(dev/(arraysize - 1));//compute standard deviation
	}
	else
		StdDev = 0;
}
//------------------------------------------------------------------------------
void saveStats(float mean, float StdDev, float coinSize[][2], int size)
{
   ofstream fout;
   fout.open("trainStats.txt");

	for (int i = 0; i < 5; i++)
		{
			cout << endl;
			for (int j = 0; j < 2; j++)
				{
					cout << coinSize[i][j] << "  ";
					fout << coinSize[i][j] << "  ";
				}
			fout << endl;
		}
	cout << endl;
					
	fout.close();
}
