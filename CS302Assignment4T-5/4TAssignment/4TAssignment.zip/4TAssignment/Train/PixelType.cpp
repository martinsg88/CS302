#include "PixelType.h"
#include <cstdlib>

//Default Constructor-----------------------------------------------------------
PixelType::PixelType()
{
	i = 0;
	j = 0;
}
//Copy Constructor-----------------------------------------------------------
PixelType::PixelType(PixelType& copy)
{
	i = copy.i;
	j = copy.j;
}
void PixelType::insert(int y, int x)
{
	j = x;
	i = y;
}
//------------------------------------------------------------------------------
PixelType& PixelType::operator= (PixelType& object)
{
	i = object.i;
	j = object.j;

	return(*this);	
}
//Default Destructor------------------------------------------------------------
PixelType::~PixelType()
{
		i = 0;
		j = 0;
}
