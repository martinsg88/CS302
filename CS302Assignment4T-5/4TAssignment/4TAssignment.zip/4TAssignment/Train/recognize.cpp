#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <string>
#include <cmath>

#include "image.h"
#include "DFSstack.h"
#include "BFSqueue.h"
#include "RegionType.h"
#include "RegionList.h"
#include "PixelType.h"
#include "PixelList.h"

using namespace std;

void displayMenu();

void executeCases(int choice);

void makestatfiles();

void recogpennies(ImageType&, char[20]);

void recognickels(ImageType&, char[20]);

void recogdimes(ImageType&, char[20]);

void recogquarters(ImageType&, char[20]);

void recogdollars(ImageType&, char[20]);

void total(RegionList<RegionType>&, char[20]);

void processImage(ImageType&, RegionList<RegionType>&);

void findComponentBFS(ImageType&, ImageType&, RegionList<RegionType>&);

void FinishedCoins(RegionList<RegionType>&,int, ImageType&, char[20]);

int recogcoins(RegionList<RegionType>&,char[],ImageType&, char[20]);

void deleteSmallHoles(RegionList<RegionType>&, int);

int readImageHeader(char[], int&, int&, int&, bool&);

int readImage(char[], ImageType&);

int writeImage(char[], ImageType&);
//==============================================================================
int main(int argc, char *argv[])
{
	makestatfiles();
	displayMenu();

 return (1);

}
//==============================================================================
void displayMenu()
{
	int choice;

		cout << "\nPlease choose from the following menu options:\n\n";

		cout << "1: Show  Pennies"	<< endl;
		cout << "2: Show  Nickels"	<< endl;
		cout << "3: Show  Dimes"	<< endl;
		cout << "4: Show  Quarters"<< endl;
		cout << "5: Show  Dollars"	<< endl;
		cout << "6: Total ammount" << endl;
		cout << "7: Exit  Prog"	<< endl;

		cout << "\nSelection: ";
		cin >> choice;

	while(choice < 1 || choice > 7)//check the selection
		{
			cout << "Selection must be between 1 and 7. Enter again.";
			cin >> choice;
		}

	if(choice == 7)
		{
			cout << "\nThanks for using the system." << endl;
		}

			executeCases(choice);
}
void makestatfiles()
{
	float readin;

	ifstream fin;
	ofstream fout;

   fin.open("trainStats.txt");	
	fout.open("stats1.txt");
	fin >> readin;
	fout << readin;	
	fin.close();
	fout.close();

   fin.open("trainStats.txt");	
	fout.open("stats2.txt");
	fin.ignore(80, '\n');
	fin >> readin;
	fout << readin;	
	fin.close();
	fout.close();

	fin.open("trainStats.txt");	
	fout.open("stats3.txt");
	fin.ignore(80, '\n');
	fin.ignore(80, '\n');
	fin >> readin;
	fout << readin;	
	fin.close();
	fout.close();

   fin.open("trainStats.txt");	
	fout.open("stats4.txt");
	fin.ignore(80, '\n');
	fin.ignore(80, '\n');
	fin.ignore(80, '\n');
	fin >> readin;
	fout << readin;	
	fin.close();
	fout.close();

   fin.open("trainStats.txt");	
	fout.open("stats5.txt");
	fin.ignore(80, '\n');
	fin.ignore(80, '\n');
	fin.ignore(80, '\n');
	fin.ignore(80, '\n');
	fin >> readin;
	fout << readin;	
	fin.close();
	fout.close();

}
//------------------------------------------------------------------------------
void executeCases(int choice)
{
	ImageType image;
	float coinSize[5][2];
	int size;
	RegionList<RegionType> regionList;
	for (int i = 0; i < 5; i++)
		for(int j = 0; j < 2; j++)
			coinSize[i][j] = 0;
	
	char inputName[20];
	
	cout << "\nEnter the name of the coins file to find information for:  ";
	cin >> inputName;
	

	switch (choice)
	{
		case 1:	
				recogpennies(image, inputName);//process pennies
		break;

		case 2:	
				recognickels(image, inputName);
		break;

		case 3:	
				recogdimes(image, inputName);		
		break;
				
		case 4:	
				recogquarters(image, inputName);
		break;

		case 5:	
				recogdollars(image, inputName);
		break;

		case 6: 
				total(regionList, inputName);
		break;
		
		case 7:
				cout << "Thanks for using this system!" << endl;
		break;

		default:

			cout << "Invalid input. Try again!" << endl;

		}
}
//------------------------------------------------------------------------------
void recogpennies(ImageType& image, char inputName[20])
{	
	int mean = 0;
	int size = 0;
	float StdDev = 0;

   RegionType regionType;
   RegionList<RegionType> regionList;

	cout << "Getting ready to process image...\n";

	processImage(image, regionList);
 cout << "Number of Pennies: " << recogcoins(regionList, "stats1.txt", image, inputName) << endl;

}
void recognickels(ImageType& image, char inputName[20])
{
	int mean = 0;
	int size = 0;
	float StdDev = 0;

   RegionType regionType;
   RegionList<RegionType> regionList;

	cout << "Getting ready to process image...\n";

	processImage(image, regionList);
	cout << "Number of Nickels: " << recogcoins(regionList, "stats2.txt", image, inputName) << endl;

}
void recogdimes(ImageType& image, char inputName[20])
{
	int mean = 0;
	int size = 0;
	float StdDev = 0;

   RegionType regionType;
   RegionList<RegionType> regionList;

	cout << "Getting ready to process image...\n";

	processImage(image, regionList);
	cout << "Number of dimes: " << recogcoins(regionList, "stats3.txt", image, inputName) << endl;

}
void recogquarters(ImageType& image, char inputName[20])
{
	int mean = 0;
	int size = 0;
	float StdDev = 0;

   RegionType regionType;
   RegionList<RegionType> regionList;

	cout << "Getting ready to process image...\n";

	processImage(image, regionList);
	cout << "Number of quarters: " << recogcoins(regionList, "stats4.txt", image, inputName) << endl;

}
void recogdollars(ImageType& image, char inputName[20])
{
	int mean = 0;
	int size = 0;
	float StdDev = 0;

   RegionType regionType;
   RegionList<RegionType> regionList;

	cout << "Getting ready to process image...\n";

	processImage(image, regionList);
	cout << "Number of dollars: " << recogcoins(regionList, "stats5.txt", image, inputName) << endl;
}
void processImage(ImageType& image, RegionList<RegionType>& regionList)
{
	cout << "Processing image...\n";

	int N, M, Q;
	bool type;
	char inputName[25];
	int threshold;
	
	cout << "\nEnter the name of the coins file to process:  ";
	cin >> inputName;

	// read image header
	readImageHeader(inputName, N, M, Q, type);
	
	// set image info
	ImageType image2(N, M, Q);
	
	// read image
	readImage(inputName, image2);
	image = image2;	

	ImageType outputImage(N,M,Q);

	for(int i = 0; i < N; i++)
	{
		for(int j = 0; j < M; j++)
		{
			outputImage.setPixelVal(i, j, 255);
		}
	}

	// get threshold
	image.displayHistogram(image, threshold);

	// threshhold image
	image.threshold(threshold, image);

	// dilate image
	image.dilate(image);

	// erode image
	image.erode(image);
	
	//ConnectedComponents
	findComponentBFS(image, outputImage, regionList);
}
void findComponentBFS(ImageType& image,ImageType& outputImage,
															RegionList<RegionType>& regionList)
{
	int vall, vali, valo, trash = 0, size = 0;//size is pixel counter
	int popi, popj, sumX = 0, sumY = 0, coinID;
	int N,M,Q; //get image info
	int marker = -1, coinComp = 0, label = 200;
	char outputName[25];
	PixelType pixelType;	
	RegionType regionType;
	PixelList<PixelType> pixelList;

	queuetype queue;//declare a queue
	
	queue.makeEmpty();
	
	outputImage.getImageInfo(N, M, Q);
		
		for(int i = 1; i < N-1; i++)//start checking the entire image
		{
			for(int j = 1; j < M-1; j++)
			{
				image.getPixelVal(i,j,vali);
				if(vali == 255)
				{	
					pixelList.MakeEmpty(); 
					image.setPixelVal(i,j,0);
					queue.enqueue(i,j);
					trash = 1;
					while(!queue.isEmpty())
					{
						queue.dequeue(popi, popj);//check nearest neighbors
						pixelType.insert(popi, popj);//insert i & j into a pixType nde
						pixelList.InsertItem(pixelType);//insert pType node into list
						for(int k = popi-1; k < popi+2; k++)
						{
							for(int l = popj-1; l <popj+2; l++)
							{	
								image.getPixelVal(k, l, vali);
								if(vali == 255)
								{
									trash++;
									queue.enqueue(k, l);
									image.setPixelVal(k, l, 0);
								}				
							}
						}
							outputImage.setPixelVal(popi,popj,label);
							regionType.insert(coinID, size, sumX, sumY, pixelList);					
					}							
							if(trash > 30 )
							{
								++coinComp;//coin counter
								label = label - 30;
								regionType.regionSize = pixelList.LengthIs();
								regionList.InsertItem(regionType);
							}

							else
							{
								deleteSmallHoles(regionList, 30);
							}
				}
			}
		}

		//set the background to black
		for(int i = 1; i < N-1; i++)
		{
			for(int j = 1; j < M-1; j++)
			{
				outputImage.getPixelVal(i,j,valo);
				if(valo == 255)
				outputImage.setPixelVal(i,j,0);
			}
		}

	writeImage("finished", outputImage);
}
int recogcoins(RegionList<RegionType>& regionList,char fileName[20],ImageType& image, char inputName[20])
{
  int coinAvg,counter=0;
  RegionType tmpReg;
  ifstream fin;
  fin.open(fileName);//opens trained file 

  fin>>coinAvg;
  regionList.ResetList();

  //go through each element in the list
  for(int i=0;i< regionList.LengthIs(); i++)
  {
      regionList.GetNextItem(tmpReg);
      if(tmpReg.regionSize < (coinAvg +280) && tmpReg.regionSize >(coinAvg-280))
       {
           counter++;
       }
  }
 FinishedCoins(regionList, coinAvg, image, inputName);
return counter;
}
void FinishedCoins(RegionList<RegionType>& regionList,int coinAvg, ImageType& image, char inputName[20])
{
	int N,M,Q, tmpx,tmpy,val;
	bool type;
	RegionType region;
	PixelType pixel;
	RegionType tmp;

	regionList.ResetList();
	int size;
	readImageHeader(inputName, N, M, Q, type);
	cout << endl;
	
	// set image info
	ImageType image2(N, M, Q);
	
	// read image
	readImage(inputName, image2);
	image = image2;	

	image.getImageInfo(N,M,Q);
	ImageType output(N,M,Q);
	
	for(int i=0; i< regionList.LengthIs();i++)
	{
	  regionList.GetNextItem(tmp);
	  if(tmp.regionSize < (coinAvg + 280) && tmp.regionSize >(coinAvg -280))
       {	
		    tmp.pixelList.ResetList();
          while((tmp.pixelList.currentPos) != NULL)
          {
				tmp.pixelList.GetNextItem(pixel);
      		image.getPixelVal(pixel.i,pixel.j,val);	 	
				output.setPixelVal(pixel.i,pixel.j,val);
          }
       }
   }
   
  for(int i=0; i < N; i++) 
  { 
	for(int j=0; j < M; j++)
	{
      output.getPixelVal(i,j,val);
	  
      if (val ==255)
		output.setPixelVal(i,j,0);//set to black
 
    }
  }
   writeImage("removed.pgm", output);
}
void total(RegionList<RegionType>& regionList, char inputName[20])
{
  int pen=0,nic=0,dim=0,quart=0,dllar=0;
  char var;
  ImageType image;

	processImage(image,regionList);//cleans image to manipulate it.
	pen = recogcoins(regionList,"stats1.txt",image, inputName);
	nic = recogcoins(regionList,"stats2.txt",image, inputName);
	dim = recogcoins(regionList,"stats3.txt",image, inputName);
	quart = recogcoins(regionList,"stats4.txt",image, inputName);
	dllar = recogcoins(regionList,"stats5.txt",image, inputName);
  cout<< "Coins                 Amount\n"
      << "Pennies: "<<pen<<"              "<<"$.0"<<pen<<endl
      << "Nickels: "<<nic<<"              "<<"$.0"<<nic*5<<endl
      << "Dimes: "<<dim<<"                "<<"$."<<dim*10<<endl
      << "Quarters: "<<quart<<"             "<<"$."<<quart*25<<endl
      << "Dollars: "<<dllar<<"              "<<"$"<<dllar<<".00"<<endl;

}
void deleteSmallHoles(RegionList<RegionType>& regionList, int size)
{
     int testsize = 0;
     bool done = true;	
     RegionType tempregion;
	
     regionList.ResetList();

     while(!done)
     {
 			regionList.GetNextItem(tempregion);
			testsize = tempregion.regionSize;
		if(testsize > size)
	  			done = true;
		else
	   	regionList.ByeTrash(tempregion); 
   }
	
}
