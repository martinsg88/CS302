#ifndef REGIONTYPE_H
#define REGIONTYPE_H

#include <cstdlib>

//#include "PixelType.h"
#include "PixelList.h"

class RegionType
{
public:
  int regionID;	
  int regionSize;
  float Xcentroid;
  float Ycentroid;
  PixelList<PixelType> pixelList;

  RegionType();								// Class constructor
  void insert(int, int, float, float, PixelList<PixelType>);
  RegionType& operator= (RegionType&);	// Overload =
  ~RegionType();								// Class destructor
	bool operator < (RegionType);
	bool operator ==(RegionType);	
	bool operator !=(RegionType);
};
#endif
