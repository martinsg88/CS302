#include "RegionType.h"
#include <cstdlib>

//Constructor-------------------------------------------------------------------
RegionType::RegionType()
{
	regionID = 0;
	regionSize = 0;
	Xcentroid = 0;	
	Ycentroid = 0;
	pixelList.MakeEmpty();
}
//------------------------------------------------------------------------------
void RegionType::insert(int RID, int size, float centroidX, float centroidY,
																PixelList<PixelType> list)
{
	regionID = RID;
	regionSize = size;
	Xcentroid = centroidX;
	Ycentroid = centroidY;
	pixelList = list;
}
//------------------------------------------------------------------------------
RegionType& RegionType::operator=(RegionType& regionObject)
{
	regionID = regionObject.regionID;
	regionSize = regionObject.regionSize;
	Xcentroid = regionObject.Xcentroid;
	Ycentroid = regionObject.Ycentroid;
	pixelList = regionObject.pixelList;
	
	return(*this);
}
//------------------------------------------------------------------------------
RegionType::~RegionType()
{
 	regionID = 0;
	regionSize = 0;
	Xcentroid = 0;
	Ycentroid = 0;
	pixelList.MakeEmpty();
}
//------------------------------------------------------------------------------
bool RegionType::operator < (RegionType region2)
{
	return(regionSize < region2.regionSize);
}
//------------------------------------------------------------------------------
bool RegionType::operator == (RegionType region2)
{
	return((regionID == region2.regionID) && (regionSize == region2.regionSize));
}
bool RegionType::operator != (RegionType region2)
{
	return((regionID == region2.regionID) && (regionSize == region2.regionSize));
}

